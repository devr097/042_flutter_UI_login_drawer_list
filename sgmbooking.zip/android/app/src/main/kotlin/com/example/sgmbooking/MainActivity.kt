package com.example.sgmbooking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:flutter/material.dart';

TextStyle black16=TextStyle(color: Colors.black,fontSize: 16);
TextStyle black17_54=TextStyle(color: Colors.black54,fontSize: 15);
